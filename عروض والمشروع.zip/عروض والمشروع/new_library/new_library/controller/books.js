window.onload = function(){
      var login_status = localStorage.getItem('login_status');
      if(!login_status)
          window.open("login.html", '_self');
          all();
}


function all(){
      //first time => read from file + copy data to localstorage (in first time localstoraeg doesn't have "books")
      // after that => read from localstorage (after localstoraeg has "books")

      let books = [];
      if( localStorage.getItem("books")){

            books = JSON.parse(localStorage.getItem("books"));
      }

      else{
             books =  getAllBooks();
      }

      let container = document.getElementById('books');

      books.forEach(item => {
            container.innerHTML += getContent(item)
      });

}

function getAllBooks(){
      let books = [];
      data.forEach(item => {
            let book = new Book (item.id, item.title, item.url, item.description)
            books.push(book);
      });

      localStorage.setItem('books', JSON.stringify(books));
      return books;
}

function getContent(item){
     let content = '<li><figure>' ;
     content += '<img src= " '   +item.url+   ' " alt="img01"/>';
     content += '<figcaption><h3>'  +item.title+  '</h3><p>'  +item.description+  '</p>';
     content +='<br><a class="btn btn-success" onclick="showBook('  +item.id+  ')"> عرض </a>';
     content +='<a class="btn btn-danger" onclick="deleteBook('  +item.id+  ')"> حذف </a>';
     content +='<a class="btn btn-primary" onclick="editBook('  +item.id+  ')"> تعديل </a></figcaption>';
     content +='</figure></li>';

     return content;

}

function addBook(){

      let books = JSON.parse(localStorage.getItem('books'));

      let title = document.getElementById('title').value;
      let description = document.getElementById('description').value;
      let image = "../assets/image/" + document.getElementById('image').files[0].name;

      let length=books.length + 1;

      let book = new Book ( length , title , image , description );

      books.push(book);
      localStorage.setItem('books', JSON.stringify(books));

      window.open("index.html", '_self');
      
}

function deleteBook(id){
   let books = JSON.parse(localStorage.getItem('books'));
   books.forEach( (item,index)=> {
     if(item.id==id){
           //delete book 
           books.splice(index , 1);
     }
   });
   localStorage.setItem('books', JSON.stringify(books));
   window.open('index.html','_self');

}

function showBook(id){

      let books = JSON.parse(localStorage.getItem('books'));
      books.forEach(item => {
             if(item.id == id){
                   localStorage.setItem('book',JSON.stringify(item));
             }
      });

      window.open('show_book.html','_self');

}
function editBook(id){

      let books = JSON.parse(localStorage.getItem('books'));
      books.forEach(item => {
             if(item.id == id){
                   localStorage.setItem('book',JSON.stringify(item));
             }
      });

      window.open('edit_book.html','_self');

}

function updateBook(){

      //get user input 
      let title = document.getElementById('title').value;
      let description = document.getElementById('description').value;
 

// about image ... if the user edited the image read from =>  "../assets/image/" + document.getElementById('image').files[0].name;
// if not edit =>  document.getElementById('image').src ;

// how i know ?????? 
// if document.getElementById('image').files[0] =! null => user edited image
//// if document.getElementById('image').files[0] = null => user not edited image
let image;
if( document.getElementById('image').files[0]){
      image = "../assets/image/" + document.getElementById('image').files[0].name;
}
else {
      image=document.getElementById('image').src ;
}

  


    //search the selected book in array books & update 
    let books = JSON.parse(localStorage.getItem('books'));
    let book  = JSON.parse(localStorage.getItem('book'));

    books.forEach(item=> {
          if ( item.id == book.id){
                item.title=title;
                item.description=description;
                item.url=image;
          }
      });

    //update local storage 
    localStorage.setItem('books',JSON.stringify(books));
    
    //go to index.html
    window.open('index.html','_self');


}
